
class Node {
    constructor(node) {
        this.id = Utils.id();
        Object.assign(this, node);
    }
}