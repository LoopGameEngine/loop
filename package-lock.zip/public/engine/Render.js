class Render {
    constructor(gameObjects, fullscreen) {
        this.fullscreen = fullscreen;
        this.gameObjects = gameObjects;
        this.canvas = document.getElementById('main');
        this.renderer = new PIXI.Renderer({ view: this.canvas });
        this.stage = new PIXI.Container();
        this.stage.sortableChildren = true;
        this.stage.interactive = true;

        window.addEventListener('resize', this.handleResize.bind(this));
        this.handleResize();
    }

    handleResize() {
        this.renderer.resize(window.innerWidth, window.innerHeight);
    }

    update() {
        this.gameObjects.forEach(gameObject => {
            if (!gameObject.sleeping) gameObject.update();
        });
        this.renderer.render(this.stage);
    }
}
